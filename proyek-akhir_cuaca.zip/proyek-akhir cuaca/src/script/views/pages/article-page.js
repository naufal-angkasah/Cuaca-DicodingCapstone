const Article = {
    async render() {
      return `
      <div class="content-header">
        <h2 class="content-header-title">Artikel Mengenai Banjir Dan Bencana Alam</h1>
      </div>
        `;
    },
  
    async afterRender() {
      
    },
  };
  
  export default Article;