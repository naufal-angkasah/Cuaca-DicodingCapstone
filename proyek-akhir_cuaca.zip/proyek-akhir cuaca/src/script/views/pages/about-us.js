const AboutUs = {
  async render() {
    return `
    <div class="content-header">
      <h2 class="content-header-title">Tentang Kami</h1>
    </div>
      `;
  },

  async afterRender() {
    
  },
};

export default AboutUs;